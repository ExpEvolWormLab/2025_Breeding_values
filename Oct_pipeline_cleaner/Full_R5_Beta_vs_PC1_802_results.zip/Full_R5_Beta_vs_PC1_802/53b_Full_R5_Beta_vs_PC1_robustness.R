## 53b_Full_R5_Beta_vs_PC1_robustness.R
## Publication sensitivity: selection-gradient beta vs fitness-blind genetic PC1.
## Uses the 802-eligible-cluster primary_survivors dataset, if both input tables
## and the weight QC table are supplied. Uses base R only.
##
## Model: train PCs and y ~ score calibration on 5 chromosomes, predict the 6th.
## This is CHROMOSOME-HELD-OUT PREDICTION WITH EVOLUTIONARY CALIBRATION;
## it is not a prospective genomic forecast with zero evolutionary outcomes.
## The block bootstrap is conditional on fitted LOCO predictions.

set.seed(20261102L)
traits <- c('SF','SB','FS','FB','BS','BF','area.F')
effect_cols <- paste0('beta_', traits, '_NaCl')
first_present <- function(paths) {
  z <- paths[file.exists(paths)]
  if (length(z)) z[1L] else NA_character_
}
read_input <- function(path) read.csv(path, stringsAsFactors=FALSE, check.names=FALSE)

q_path <- first_present(c(
  'selection_results/drift_oneG0_nullfit/R5/11_Clusters_selection_and_GWAS_09f.csv',
  '11_Clusters_selection_and_GWAS_09f.csv'))
e_path <- first_present(c(
  'selection_results/unified_frequency_inclusive_R5/45_All_R5_clusters_GWAS_evolution_predictions.csv',
  '45_All_R5_clusters_GWAS_evolution_predictions.csv'))
w_path <- first_present(c(
  'selection_results/drift_oneG0_nullfit/R5/multivariate_prediction/13_Gradient_weight_QC.csv',
  '13_Gradient_weight_QC.csv'))
if (anyNA(c(q_path,e_path,w_path))) {
  stop('Missing required input. Supply 11_Clusters_selection_and_GWAS_09f.csv, ',
       '45_All_R5_clusters_GWAS_evolution_predictions.csv and 13_Gradient_weight_QC.csv')
}
Q <- read_input(q_path)
E <- read_input(e_path)
W <- read_input(w_path)
needed_q <- c('group','chr',effect_cols)
needed_e <- c('group','chr','ps','block','slope','scenario','reason','pred_full','pred_SB',
              'LOCO_full','LOCO_SB')
if (!all(needed_q %in% names(Q)) || !all(needed_e %in% names(E))) {
  stop('Input CSV schema mismatch')
}
E <- E[E$scenario == 'primary_survivors' & E$reason == 'eligible' &
         is.finite(E$slope), , drop=FALSE]
if (anyDuplicated(E$group) || anyDuplicated(Q$group)) stop('Duplicate group identifiers')
idx <- match(as.character(E$group),as.character(Q$group))
if (anyNA(idx)) stop('Missing GWAS effects for eligible evolutionary groups')
Q <- Q[idx,,drop=FALSE]
if (any(as.character(E$chr)!=as.character(Q$chr))) stop('Chromosome mismatch')
X <- as.matrix(Q[,effect_cols,drop=FALSE]); storage.mode(X) <- 'double'
if (any(!is.finite(X))) stop('Nonfinite GWAS effects in eligible clusters')
colnames(X) <- traits
W <- W[match(traits,W$trait),,drop=FALSE]
if (anyNA(W$trait)) stop('Missing beta weights for one or more traits')
w <- as.numeric(W$weight_full_GWAS_scale)
if (any(!is.finite(w))) stop('Nonfinite beta weights')
beta_score <- drop(X %*% w)
if (max(abs(beta_score-E$pred_full)) > 1e-9) stop('Beta projection differs from script 45')
if (max(abs(X[,'SB']-E$pred_SB)) > 1e-9) stop('SB predictor differs from script 45')
if (nrow(E) != 802L) message('CAUTION: matched ',nrow(E),' clusters, not 802')

## Compute CV predictions with a newly fitted PCA in each training set.
## The sign of PC scores is arbitrary and cannot affect calibrated predictions.
fit_cal <- function(x_train,x_test,y_train) {
  z <- lm.fit(cbind(1, x_train), y_train)
  if (any(!is.finite(z$coefficients))) stop('Nonestimable calibration')
  drop(cbind(1, x_test) %*% z$coefficients)
}
run_loco <- function(E, X, w, scenario) {
  y <- as.numeric(E$slope)
  ch <- as.character(E$chr)
  bs <- drop(X %*% w)
  p <- data.frame(group=E$group,chr=ch,ps=E$ps,block=E$block,slope=y,
                  raw_beta=bs,raw_SB=X[,'SB'], beta=NA_real_, SB=NA_real_,
                  PC1_cov=NA_real_, PC1_corr=NA_real_)
  loading_rows <- list()
  for (cc in unique(ch)) {
    train <- ch != cc; test <- ch == cc
    p$beta[test] <- fit_cal(bs[train],bs[test],y[train])
    p$SB[test]   <- fit_cal(X[train,'SB'],X[test,'SB'],y[train])
    for (kind in c('cov','corr')) {
      pc <- prcomp(X[train,,drop=FALSE],center=TRUE,scale.=(kind=='corr'))
      v  <- pc$rotation[,1L]
      mu <- pc$center
      scl <- if (kind=='corr') pc$scale else rep(1,length(mu))
      standardize <- function(M) sweep(sweep(M,2L,mu,'-'),2L,scl,'/')
      s_train <- drop(standardize(X[train,,drop=FALSE]) %*% v)
      s_test  <- drop(standardize(X[test,,drop=FALSE]) %*% v)
      ## Orient PC1 toward beta for interpretable loading signs. This uses
      ## only ancestral GWAS effects and fitness weights, never evolution.
      if (cor(s_train,bs[train]) < 0) {
        v <- -v; s_train <- -s_train; s_test <- -s_test
      }
      p[test,paste0('PC1_',kind)] <- fit_cal(s_train,s_test,y[train])
      loading_rows[[length(loading_rows)+1L]] <- data.frame(
        scenario=scenario,heldout_chromosome=cc,kind=kind,trait=traits,
        loading=as.numeric(v),PC1_fraction=pc$sdev[1L]^2/sum(pc$sdev^2),
        n_training=sum(train),n_testing=sum(test))
    }
  }
  sst <- sum((y-mean(y))^2)
  metrics <- do.call(rbind,lapply(c('beta','SB','PC1_cov','PC1_corr'),function(mod) {
    z <- p[[mod]]
    data.frame(scenario=scenario,n_clusters=length(y),n_chromosomes=length(unique(ch)),
      n_blocks=length(unique(E$block)),model=mod,
      LOCO_R2=1-sum((y-z)^2)/sst,LOCO_MSE=mean((y-z)^2),
      response_prediction_r=cor(y,z),LOCO_sign_accuracy=mean(sign(y)==sign(z)))
  }))
  list(pred=p,metrics=metrics,loadings=do.call(rbind,loading_rows))
}

all_result <- run_loco(E,X,w,'Full_802')
qc <- data.frame(n_clusters=nrow(E), n_blocks=length(unique(E$block)),
  max_diff_raw_beta=max(abs(beta_score-E$pred_full)),
  max_diff_raw_SB=max(abs(X[,'SB']-E$pred_SB)),
  max_diff_LOCO_beta=max(abs(all_result$pred$beta-E$LOCO_full)),
  max_diff_LOCO_SB=max(abs(all_result$pred$SB-E$LOCO_SB)))
if (qc$max_diff_LOCO_beta>1e-9 || qc$max_diff_LOCO_SB>1e-9)
  stop('Recomputed β or SB LOCO predictions disagree with script 45')

## Sensitivity models RE-FITTED after excluding the focal block or chromosome.
sens <- list(all_result)
if (any(E$block=='V_3')) {
  k <- E$block!='V_3'
  sens[[length(sens)+1L]] <- run_loco(E[k,,drop=FALSE],X[k,,drop=FALSE],w,'Exclude_V_3_refit')
}
if (any(E$chr=='V')) {
  k <- E$chr!='V'
  sens[[length(sens)+1L]] <- run_loco(E[k,,drop=FALSE],X[k,,drop=FALSE],w,'Exclude_V_refit')
}
metrics <- do.call(rbind,lapply(sens,`[[`,'metrics'))

## Paired 2-Mb genomic-block bootstrap of beta-minus-comparator MSE.
## The test does not re-estimate PCA/calibration in each bootstrap draw.
block_i <- split(seq_len(nrow(E)),as.character(E$block))
block_ids <- names(block_i)
B <- 5000L
p <- all_result$pred
y <- p$slope
set.seed(20261102L)
boot <- do.call(rbind,lapply(c('PC1_cov','PC1_corr','SB'),function(other) {
  d <- (y-p[[other]])^2-(y-p$beta)^2
  draw <- replicate(B, {
    picked <- sample(block_ids,length(block_ids),replace=TRUE)
    ix <- unlist(block_i[picked],use.names=FALSE)
    mean(d[ix])
  })
  data.frame(comparator=other, delta_MSE_beta_advantage=mean(d),
    CI_low=unname(quantile(draw,0.025)),CI_high=unname(quantile(draw,0.975)),
    positive_fraction=mean(draw>0),
    bootstrap_sign_p_exploratory=min(1,2*min(mean(draw<=0),mean(draw>=0))))
}))

chrom_sensitivity <- do.call(rbind,lapply(unique(E$chr),function(cc) {
  z <- as.character(E$chr)==cc
  yy <- y[z]
  data.frame(chr=cc,n_clusters=sum(z),
    beta_R2=1-sum((yy-p$beta[z])^2)/sum((yy-mean(yy))^2),
    SB_R2=1-sum((yy-p$SB[z])^2)/sum((yy-mean(yy))^2),
    PC1_cov_R2=1-sum((yy-p$PC1_cov[z])^2)/sum((yy-mean(yy))^2),
    delta_MSE_beta_vs_PC1_cov=mean((yy-p$PC1_cov[z])^2-(yy-p$beta[z])^2))
}))
p$delta_SE_beta_vs_PC1_cov <- (y-p$PC1_cov)^2-(y-p$beta)^2
block_sensitivity <- aggregate(p$delta_SE_beta_vs_PC1_cov,
  by=list(block=p$block),FUN=function(z)c(n=length(z),sum=sum(z),mean=mean(z)))
block_sensitivity <- data.frame(block=block_sensitivity$block,
  n=block_sensitivity$x[,'n'],sum_delta=block_sensitivity$x[,'sum'],
  mean_delta=block_sensitivity$x[,'mean'])
block_sensitivity <- block_sensitivity[order(-block_sensitivity$sum_delta),]

out <- 'selection_results/beta_vs_PC1'
dir.create(out,showWarnings=FALSE,recursive=TRUE)
write.csv(metrics,file.path(out,'53b_Full802_and_refitted_sensitivity_metrics.csv'),row.names=FALSE)
write.csv(p,file.path(out,'53b_Full802_matched_predictions.csv'),row.names=FALSE)
write.csv(all_result$loadings,file.path(out,'53b_PC1_loadings.csv'),row.names=FALSE)
write.csv(chrom_sensitivity,file.path(out,'53b_Chromosome_sensitivity.csv'),row.names=FALSE)
write.csv(boot,file.path(out,'53b_Paired_block_bootstrap.csv'),row.names=FALSE)
write.csv(block_sensitivity,file.path(out,'53b_Block_contribution_diagnostics.csv'),row.names=FALSE)
write.csv(qc,file.path(out,'53b_Input_reproduction_QC.csv'),row.names=FALSE)
cat('\nFULL AND SENSITIVITY RESULTS (each PCA and calibration refitted):\n')
print(metrics[,c('scenario','model','n_clusters','LOCO_R2','LOCO_MSE')],row.names=FALSE)
cat('\nPaired beta advantage uncertainty (positive = beta better):\n')
print(boot,row.names=FALSE)
cat('\nInput and original-model reproduction:\n')
print(qc,row.names=FALSE)
