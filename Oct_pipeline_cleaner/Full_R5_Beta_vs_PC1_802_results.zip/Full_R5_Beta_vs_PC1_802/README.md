# Beta versus PC1 — full 802 R5 clusters, 2 November 2026

## Inputs

1. `11_Clusters_selection_and_GWAS_09f.csv` — full R5 GWAS effects; 1,089 total regions.
2. `45_All_R5_clusters_GWAS_evolution_predictions.csv` — script 45 responses, eligibility and LOCO predictions.
3. `13_Gradient_weight_QC.csv` — pre-estimated fitness-derived weights on the GWAS effect scale.

Place these files in the paths expected by `53b_Full_R5_Beta_vs_PC1_robustness.R` (either in your project root or in its documented pipeline subfolders). Run `source("53b_Full_R5_Beta_vs_PC1_robustness.R")` from the project root. Output is written to `selection_results/beta_vs_PC1/`.

## Scope and estimand

All 802 eligible R5 clusters from primary surviving GA1/GA2/GA4 populations are used, including rare-frequency loci added to the extended analysis. PCA is recomputed **separately in the training five chromosomes** for every held-out chromosome. The model also calibrates the genomic score to the observed evolutionary slope using the other chromosomes. **This is not a completely evolutionary-data-free prediction.** PC1 is fitness-blind prior to the calibration, whereas the selection-gradient beta score uses fitness information from the ancestral panel.

## Independent numerical verification (Python)

The package includes CSV results recomputed in Python. R has not been run in this environment. Exact agreement with script 45 for beta score and LOCO_full/SB is verified to numerical precision. The R script checks these internally.

Main results: full beta LOCO R² 0.079606, SB 0.071579, covariance PC1 0.047407, correlation PC1 0.047711. Paired 2-Mb genomic block bootstrap beta-versus-covariance-PC1 MSE improvement approximately 6.89e-8, 95% interval -8.23e-8 to 3.19e-7 (20,000 bootstrap samples; script's 5,000 will vary slightly).

## Key sensitivity result

The overall difference is largely driven by 12 loci in genomic block `V_3` (chr V ~6–8 Mb). **Re-fitting** after exclusion of `V_3` gives LOCO R² beta 0.053385, PC1 0.064792. Re-fitting after excluding chromosome V entirely gives beta 0.053205, PC1 0.074833. It is not valid to claim general genome-wide superiority of beta based on the all-cluster aggregate.

Multiple clusters in the same 2-Mb block cannot automatically be interpreted as independent causal loci. No demonstration of molecular pleiotropy versus linkage follows from these results alone.

## Files

- `53b_Full_R5_Beta_vs_PC1_robustness.R` — manuscript-ready reproducible R pipeline (base R only).
- `53_Full802_LOCO_metrics.csv` — all 802, β / SB / PC1 variants (and exploratory PC2).
- `53_Full802_Matched_predictions.csv` — all matched cluster-level predictions.
- `53_Full802_PC_loadings.csv` — training-chromosome PC loadings and eigenvalue fractions.
- `53_Full802_Chromosome_sensitivity.csv` — performance by test chromosome.
- `53_Full802_Paired_block_bootstrap.csv` — exploratory pairwise error uncertainty, conditional on LOCO fits.
- `53_Full802_Refitted_sensitivity.csv` — full / exclude V_3 / exclude V models, re-estimating PCs and calibrations.
- `53_Full802_Input_QC.csv` — replication of original β and SB scores and LOCO predictions.

`full802_sensitivity.py` is included to reproduce the Python re-fit sensitivity comparisons; `full802_pc1_compute.py` to reproduce the full-802 Python diagnostics.

## Region-specific contribution

`53_Full802_Block_contributions.csv` quantifies the per-block contributions to the β minus PC1 squared-error advantage. Block `V_3` contributes more than the net sum across all blocks; this is an influence diagnostic, **not** an additional hypothesis test. Its 12 testable clusters should not be treated as 12 independently selected variants.
