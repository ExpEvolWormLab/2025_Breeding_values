import pandas as pd, numpy as np
from pathlib import Path
p=Path('/mnt/data/Full_R5_Beta_vs_PC1_802')
x=pd.read_csv('/mnt/data/11_Clusters_selection_and_GWAS_09f.csv')
y=pd.read_csv('/mnt/data/pleiotropy_new_results/45_All_R5_clusters_GWAS_evolution_predictions.csv')
w=pd.read_csv('/mnt/data/13_Gradient_weight_QC.csv')
t=['SF','SB','FS','FB','BS','BF','area.F'];co=['beta_'+n+'_NaCl' for n in t];w=w.set_index('trait').loc[t,'weight_full_GWAS_scale'].to_numpy()
y=y[(y.scenario=='primary_survivors')&(y.reason=='eligible')].merge(x[['group',*co]],on='group',validate='one_to_one'); y=y[np.isfinite(y.slope)].copy()
def calc(df):
 yy=df.slope.to_numpy(); X=df[co].to_numpy(); chrom=df.chr.to_numpy();b=X@w;out=np.empty((len(df),3));
 for c in sorted(set(chrom)):
  tr=chrom!=c;te=~tr
  def pred(sc,sv):
   A=np.column_stack([np.ones(tr.sum()),sc]);v=np.linalg.lstsq(A,yy[tr],rcond=None)[0]
   return np.column_stack([np.ones(te.sum()),sv])@v
  out[te,0]=pred(b[tr],b[te]);out[te,1]=pred(X[tr,1],X[te,1]);
  mu=X[tr].mean(0)
  _,v=np.linalg.eigh(np.cov(X[tr],rowvar=False));pc=v[:,-1]
  out[te,2]=pred((X[tr]-mu)@pc,(X[te]-mu)@pc)
 R={}
 for j,name in enumerate(('beta','SB','PC1_cov')):
  R['R2_'+name]=1-np.sum((yy-out[:,j])**2)/np.sum((yy-yy.mean())**2)
  R['MSE_'+name]=np.mean((yy-out[:,j])**2)
 R['delta_MSE_beta_vs_PC1_cov']=R['MSE_PC1_cov']-R['MSE_beta']
 R['scenario']='all' if len(df)==802 else 'sensitivity'
 R['n_clusters']=len(df);R['n_chromosomes']=len(set(chrom));R['n_blocks']=df.block.nunique()
 return R
ans=[]
for desc,z in [('Full 802',y),('Exclude V_3: re-fit all folds',y[y.block!='V_3']),('Exclude chr V: re-fit all folds',y[y.chr!='V'])]:
 r=calc(z);r['scenario']=desc;ans.append(r)
a=pd.DataFrame(ans)
a.to_csv(p/'53_Full802_Refitted_sensitivity.csv',index=False)
print(a.to_string(index=False,float_format=lambda x:f'{x:.10f}'))
