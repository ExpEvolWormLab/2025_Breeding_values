import numpy as np,pandas as pd
from pathlib import Path
D=Path('/mnt/data/Full_R5_Beta_vs_PC1_802')
D.mkdir(exist_ok=True)
E=pd.read_csv('/mnt/data/pleiotropy_new_results/45_All_R5_clusters_GWAS_evolution_predictions.csv')
Q=pd.read_csv('/mnt/data/11_Clusters_selection_and_GWAS_09f.csv')
W=pd.read_csv('/mnt/data/13_Gradient_weight_QC.csv')
traits=['SF','SB','FS','FB','BS','BF','area.F']; cols=['beta_'+t+'_NaCl' for t in traits]
E=E[(E.scenario=='primary_survivors')&(E.reason=='eligible')&np.isfinite(E.slope)].copy()
a=E.merge(Q[['group','chr',*cols]],on='group',how='inner',validate='one_to_one',suffixes=('','_gwas'))
assert len(a)==802 and all(a.chr==a.chr_gwas)
assert a[cols].notna().all().all()
a=a.sort_values(['chr','ps','group']).reset_index(drop=True)
X=a[cols].to_numpy(dtype=float)
w=W.set_index('trait').loc[traits,'weight_full_GWAS_scale'].to_numpy(dtype=float)
beta=X@w
assert np.max(abs(beta-a.pred_full.values))<1e-12
assert np.max(abs(X[:,1]-a.pred_SB.values))<1e-12
y=a.slope.to_numpy(float); chr=a.chr.to_numpy(); block=a.block.to_numpy()
res=a[['group','chr','ps','block','slope']].copy()
res['raw_beta']=beta
res['raw_SB']=X[:,1]
for name in ['beta','SB','PC1_cov','PC1_corr','PC2_cov','PC2_corr']:
 res[name]=np.nan
load=[]
for held in sorted(set(chr)):
 tr=chr!=held;te=~tr
 def calibrate(rawtr,rawte):
  coeff=np.linalg.lstsq(np.column_stack((np.ones(tr.sum()),rawtr)),y[tr],rcond=None)[0]
  return np.column_stack((np.ones(te.sum()),rawte))@coeff
 res.loc[te,'beta']=calibrate(beta[tr],beta[te])
 res.loc[te,'SB']=calibrate(X[tr,1],X[te,1])
 for kind in ('cov','corr'):
  mu=X[tr].mean(0)
  sd=X[tr].std(0,ddof=1) if kind=='corr' else np.ones(7)
  ztr=(X[tr]-mu)/sd
  zte=(X[te]-mu)/sd
  vt=np.linalg.eigh(np.cov(ztr,rowvar=False))
  eig,vec=vt[0][::-1],vt[1][:,::-1]
  for comp in range(2):
   v=vec[:,comp].copy()
   # Sign orientation is irrelevant to fitted LOCO prediction; use alignment to beta for stable output.
   if np.corrcoef(ztr@v,beta[tr])[0,1]<0:v=-v
   nm=('PC1_' if comp==0 else 'PC2_')+kind
   res.loc[te,nm]=calibrate(ztr@v,zte@v)
   for t,l in zip(traits,v):load.append(dict(holdout_chr=held,kind=kind,component=comp+1,trait=t,loading=l,explained_fraction=eig[comp]/sum(eig),n_train=int(tr.sum()),n_test=int(te.sum())))
SST=sum((y-y.mean())**2)
metrics=[]
for nm in ['beta','SB','PC1_cov','PC1_corr','PC2_cov','PC2_corr']:
 p=res[nm].values
 metrics.append(dict(model=nm,n_clusters=len(y),n_blocks=len(set(block)),LOCO_R2=1-sum((y-p)**2)/SST,LOCO_MSE=np.mean((y-p)**2),prediction_vs_response_r=np.corrcoef(y,p)[0,1],direction_accuracy_LOCO=np.mean(np.sign(y)==np.sign(p))))
met=pd.DataFrame(metrics)
checks={
 'reconstructed_beta_max_abs_diff':max(abs(beta-a.pred_full.values)),
 'sb_max_abs_diff':max(abs(X[:,1]-a.pred_SB.values)),
 'LOCO_beta_vs_existing_max_abs_diff':max(abs(res.beta-a.LOCO_full)),
 'LOCO_SB_vs_existing_max_abs_diff':max(abs(res.SB-a.LOCO_SB))
}
print('checks',checks)
print(met.to_string(index=False,float_format=lambda x:f'{x:.10f}'))
# beta and PC1 genetic score similarity per training chromosome, after deterministic sign orientation
load_df=pd.DataFrame(load)
chrom_rows=[]
for held in sorted(set(chr)):
 idx=chr==held;yy=y[idx]
 row={'holdout_chr':held,'n_clusters':int(idx.sum())}
 for nm in ['beta','SB','PC1_cov','PC1_corr']:
  p=res.loc[idx,nm].values
  row['R2_'+nm]=1-sum((yy-p)**2)/sum((yy-yy.mean())**2)
  row['MSE_'+nm]=np.mean((yy-p)**2)
 row['delta_MSE_beta_vs_PC1_cov']=row['MSE_PC1_cov']-row['MSE_beta']
 row['delta_MSE_beta_vs_SB']=row['MSE_SB']-row['MSE_beta']
 chrom_rows.append(row)
chrom_df=pd.DataFrame(chrom_rows)
print('CHROMOSOME:',chrom_df.to_string(index=False,float_format=lambda x:f'{x:.9f}'))
# paired hierarchical 2-Mb block bootstrap of average paired SE differences (conditioning on fitted models)
rng=np.random.default_rng(20261102)
blocks={k:np.flatnonzero(block==k) for k in sorted(set(block))}
keys=list(blocks)
B=20000
indices=[np.concatenate([blocks[keys[j]] for j in rng.integers(len(keys),size=len(keys))]) for _ in range(B)]
boot=[]
for compare in ['PC1_cov','PC1_corr','SB']:
 delta=(y-res[compare].values)**2-(y-res.beta.values)**2
 obs=delta.mean()
 draws=np.array([delta[idx].mean() for idx in indices])
 ci=np.quantile(draws,[0.025,0.975])
 # do not label bootstrap sign fraction a calibrated p value
 boot.append(dict(comparator=compare,n_blocks=len(keys),n_clusters=len(y),delta_MSE_beta_advantage=obs,CI_low=ci[0],CI_high=ci[1],fraction_draws_positive=float(np.mean(draws>0)),bootstrap_sign_p_exploratory=float(min(1,2*min(np.mean(draws<=0),np.mean(draws>=0))))))
boot_df=pd.DataFrame(boot)
print('BOOT:',boot_df.to_string(index=False,float_format=lambda x:f'{x:.10g}'))
# cluster-sign comparison raw beta, raw SB oriented selection sign. PC1 not naturally oriented toward fitness.
acc_beta=np.sign(beta)==np.sign(y)
acc_sb=np.sign(X[:,1]*w[1])==np.sign(y)
print('raw directional accuracy beta',acc_beta.mean(),acc_beta.sum(),'SB',acc_sb.mean(),acc_sb.sum(),'disagreement',np.sum(np.sign(beta)!=np.sign(X[:,1]*w[1])))
res['raw_beta_correct']=acc_beta
res['raw_SB_correct']=acc_sb
# Rank of PC1 and correlations with beta (uses covariance standardized effect)
coef=load_df[(load_df.kind=='cov')&(load_df.component==1)].pivot(index='holdout_chr',columns='trait',values='loading')[traits]
print('PC1 covariance fraction:', load_df[(load_df.kind=='cov')&(load_df.component==1)].drop_duplicates('holdout_chr')[['holdout_chr','explained_fraction']].to_string(index=False))
print('loadings:',coef.round(3).to_string())
met.to_csv(D/'53_Full802_LOCO_metrics.csv',index=False)
res.to_csv(D/'53_Full802_Matched_predictions.csv',index=False)
load_df.to_csv(D/'53_Full802_PC_loadings.csv',index=False)
chrom_df.to_csv(D/'53_Full802_Chromosome_sensitivity.csv',index=False)
boot_df.to_csv(D/'53_Full802_Paired_block_bootstrap.csv',index=False)
pd.DataFrame([checks]).to_csv(D/'53_Full802_Input_QC.csv',index=False)
