# Scripts 09c and 09d: drift-aware SNP trajectory analysis

These files are **new complementary analyses** for scripts 08/09, not a replacement
for the original allele orientation or log-odds slope estimates. Run from the
project root and place all three `.R` files together there.

## Design and scientific choices

- Uses **both** generation-zero samples A00 and A6G140 (G0, replicate IDs 1 and 2),
  and the four independent evolving replicate populations at generations
  10, 36, and (when present) 50. Replicate 5 lacks generation 50.
- Uses the GWAS-ALT-oriented read counts established in script 09. No re-polarization
  of the composite or cluster genotype is performed here.
- A diploid effective population size of **1000** is the primary scenario.
  Sensitivity: **500 and 2000**.
- Uses the **frequency slope** (change in allele frequency per generation)
  in a generalized least-squares regression with a common intercept. It is
  **not the classical selection coefficient s**; the descriptive original
  script 09 logit slope remains in the output for comparison.
- The GLS neutral variance combines sequencing read sampling and neutral
  Wright–Fisher covariance for time points within an evolved replicate.
  Conditional covariance (approximate):
  `p0*(1-p0)*{I(same evolving replicate)*(1-(1-1/(2Ne))^min(t,s)) + I(same pool)/depth}`.
  The two G0 read observations share a fitted ancestral intercept but have
  independent sampling errors. Technical errors, linkage, and variable Ne
  are NOT modeled by this analytic covariance.
- `pool_individuals = NA_real_` assumes a sufficiently large physical DNA pool;
  the **census size of 10,000 is NOT the number of individuals sampled for
  sequencing**. If the actual DNA pool contributor count is known, set it
  in BOTH scripts, which adds a finite-pool-sampling variance approximation.
- **Do not interpret BH/BY discoveries from 09c as calibrated** until 09d's
  neutral simulations show acceptable type-I-error rates, especially for
  small/large ancestral allele frequencies. The covariance/normal tests
  are approximations; with sparse 13-pool data and a plug-in p0, calibration
  can be imperfect.
- 09d uses **exact discrete-generation diploid Wright–Fisher neutral simulation**,
  independently for each evolving population, and then simulates read counts
  (and optionally individuals in the DNA pool) at the *observed* depths and
  generations. G0 is sampled twice independently from the common founder p0.
- The 09d simulations are on a **small SNP subset**, stratified by initial
  frequency and coverage, plus leading candidate loci. This makes the analysis
  computationally practical. Simulated loci are treated independently; these
  simulations do **not** account for LD correlations among SNPs, joint genomic
  false discovery rates, selection on linked loci, or estimation of Ne.

## Running

```r
source("09c_Drift_GLS_genomewide.R")
source("09d_WF_neutral_calibration.R")
```

### Performance

09c: ~204k SNPs, each requiring an inexpensive 13x13 Cholesky factorization.
Default uses 6 forked workers on Unix/macOS, 1 on Windows. `Ne_values <- c(1000)`
only initially; add `500,2000` if the primary results look interpretable.
Every additional Ne scenario requires another genome-wide pass.

09d: default pilot is ~50–80 SNPs x **500** null replicates x **3** Ne
scenarios, each with 4 evolved populations for up to 50 generations.
This is many fewer simulations than 204k SNPs x 10k replicates. If the null
calibration is unsatisfactory, first inspect allele-frequency and read-depth
strata, sample quality, and the estimated Ne. Increasing simulations will
NOT repair an incorrectly specified null model.

For more precise validation only, increase `n_sim` to 2000 or more and
`random_per_stratum` to 6–10; be prepared for longer runtimes. The exact
simulation cost scales approximately with `(number of loci)*(n_sim)*Ne_scenarios*50`.

### Outputs

09c: `selection_results/drift/09c_SNP_drift_Ne1000.csv` (plus any sensitivity
Ne scenarios) with `p0_hat`, `slope_freq`, `Z_drift`, `p_drift`, `p_drift_BH`,
`p_drift_BY`, `n_G0`, the standardized difference between the two G0 frequencies (`baseline_Z`), and the original logit slope.

09d: `09d_WF_locus_calibration.csv`, `09d_WF_null_calibration_summary.csv`,
and `09d_WF_null_QQ.pdf`.

## Critical interpretation

- The 09c p-values use a normal approximation to a neutral WF process,
  evaluated with initial p0 estimated from two baseline read pools. Their
  calibration is particularly fragile near p0=0 and p0=1; such SNPs are
  explicitly flagged.
- 09d empirical per-site p-values have resolution `1/(n_sim+1)` and **cannot**
  be BH-corrected across 204k tested SNPs as though each had fully simulated
  null replicates. This script tests calibration, not genome-wide empirical FDR.
- The two generation-zero samples are both retained by design. That is a
  reproducibility choice, not confirmation they are biologically interchangeable.
  Inspect `baseline_Z`: a genome-wide excess of large baseline differences
  would indicate that read sampling alone is insufficient to explain
  differences between the two G0 samples.
- If simulated Z variances deviate markedly from one, or simulated tails
  exceed nominal thresholds, report that the fast test needs revised
  calibration BEFORE using its selected/nonsignificant calls in script 10.
- A fully definitive test should incorporate the *actual biological pool
  contributor counts*, potential correlated technical errors, uncertainty
  in Ne, and linkage at the genomic region level if those are important
  contributors to the manuscript's central selection claims.
